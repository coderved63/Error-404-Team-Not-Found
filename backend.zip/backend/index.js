const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const { ethers } = require("ethers");

dotenv.config();

const app = express();
const port = process.env.PORT || 3001;
app.use(cors());
app.use(express.json());

// Supported RPC URLs
const RPC_URLS = {
  "0x1": process.env.ETHEREUM_RPC, // Ethereum Mainnet
  "0xaa36a7": process.env.SEPOLIA_RPC, // Sepolia Testnet
};

// Load wallet from private key
let wallet;
try {
  if (!process.env.PRIVATE_KEY) {
    throw new Error("Private key missing in .env file");
  }
  wallet = new ethers.Wallet(process.env.PRIVATE_KEY);
  console.log(`✅ Wallet loaded: ${wallet.address}`);
} catch (error) {
  console.error("❌ Error loading wallet:", error.message);
  process.exit(1);
}

// Get Balance
app.get("/getBalance", async (req, res) => {
  try {
    const { userAddress, selectedChain } = req.query;

    if (!userAddress) {
      return res.status(400).json({ error: "Missing user address" });
    }
    if (!selectedChain) {
      return res.status(400).json({ error: "Missing chain" });
    }
    if (!RPC_URLS[selectedChain]) {
      return res.status(400).json({ error: "Invalid chain selected" });
    }
    if (!ethers.isAddress(userAddress)) {
      return res.status(400).json({ error: "Invalid Ethereum address" });
    }

    // Connect to provider
    const provider = new ethers.JsonRpcProvider(RPC_URLS[selectedChain]);

    console.log(`Fetching balance for ${userAddress} on chain ${selectedChain}...`);

    const balanceWei = await provider.getBalance(userAddress);
    const balanceEth = ethers.formatEther(balanceWei);

    console.log(`Balance fetched: ${balanceEth} ETH`);

    res.json({
      address: userAddress,
      balance: balanceEth,
      chain: selectedChain,
    });
  } catch (error) {
    console.error("❌ Error fetching balance:", error.message);
    res.status(500).json({ error: "Failed to fetch balance", details: error.message });
  }
});

// Send Token
app.post("/sendToken", async (req, res) => {
  try {
    const { recipient, amount, selectedChain } = req.body;

    if (!recipient || !amount || !selectedChain) {
      return res.status(400).json({ error: "Missing recipient, amount, or chain" });
    }
    if (!RPC_URLS[selectedChain]) {
      return res.status(400).json({ error: "Invalid chain selected" });
    }
    if (!ethers.isAddress(recipient)) {
      return res.status(400).json({ error: "Invalid recipient address" });
    }

    // Connect wallet to provider
    const provider = new ethers.JsonRpcProvider(RPC_URLS[selectedChain]);
    const walletWithProvider = wallet.connect(provider);

    // Get wallet balance
    const walletBalance = await provider.getBalance(wallet.address);
    const walletBalanceEth = ethers.formatEther(walletBalance);
    
    if (parseFloat(walletBalanceEth) < parseFloat(amount)) {
      return res.status(400).json({ error: "Insufficient funds" });
    }

    // Create and send transaction
    const tx = await walletWithProvider.sendTransaction({
      to: recipient,
      value: ethers.parseEther(amount),
    });

    console.log(`🔄 Sending ${amount} ETH to ${recipient} on chain ${selectedChain}...`);
    await tx.wait();
    console.log(`✅ Transaction confirmed: ${tx.hash}`);

    // Fetch updated balance
    const updatedBalanceWei = await provider.getBalance(wallet.address);
    const updatedBalanceEth = ethers.formatEther(updatedBalanceWei);

    res.json({
      success: true,
      transactionHash: tx.hash,
      updatedBalance: updatedBalanceEth,
    });
  } catch (error) {
    console.error("❌ Error sending token:", error.message);
    res.status(500).json({ error: "Failed to send token", details: error.message });
  }
});

// Start the server
app.listen(port, () => console.log(`🚀 Server running on port ${port}`));
